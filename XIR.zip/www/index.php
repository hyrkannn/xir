<!DOCTYPE html>
<html lang="fa-IR">
	<head id="Head">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>
			کتابخانه فرهنگیان
		</title>
		</link rel="stylesheet" href="data/ux.css">
		<style type="text/css">
			.bg{
				background-image:url(https://s4.picofile.com/file/8288164292/P1020608.jpg);
				background-size: 100% auto;
				position:fixed;
				width:112%;
				height:120%;
				margin-top:-10%;
				margin-left:-6.5%;
			}
			.reg{
				text-align:center;
				position:fixed;
				width:13%;
				top:21%;
				left:16%;
			}
            .banner{
                text-align:center;
                position:fixed;
				width:20%;
				top:8.7%;
                left:38%;
                z-index:1;
            }
            .slide{
                text-align:center;
                position:fixed;
				width:20%;
				top:40%;
                left:38%;
                z-index:1;
            }
            .slidebtm{
                margin-top:42%;
                margin-left:8%;
                color:#ffffff;
                font-size:20px;
                text-align:center;
            }
            .slctd{
                color:#141f5f;
            }
            .dot{
                color:#ffffff;
            }
            .search{
				text-align:center;
				position:fixed;
				width:13%;
				top:22%;
				left:51.8%;
			}
			.news{
				text-align:right;
                word-wrap: break-word;
				position:fixed;
				width:55%;
				top:30%;
				right:25%;
			}
            .event{
				color:#ffffff;
				font-size:15px;
				font-weight:italic;
                word-wrap:break-word;
			}
			.event:visited{
				color:#ffffff;
			}
			.gls{
				background-color:rgba(20,31,95,0.8);
				text-align:center;
				border-radius:50px;
				position:fixed;
				width:61.8%;
				height:60%;
				top:20%;
				left:16.5%;
			}
			.wgls{
				background-image:url(http://<?php echo $_SERVER['SERVER_NAME'] ?>/data/wgls.png);
                background-size:auto 100%;
				text-align:center;
				border-radius:0px;
				position:fixed;
				width:9%;
				height:60%;
				top:20%;
				left:73.5%;
                z-index:-1;
			}
            .menu{
                margin-top:10%;
                margin-left:50%;
                margin-bottom:10%;
            }
            .menuslct{
                stroke:#18a4bc;
            }
            .menubtn{
                stroke:#141f5f;
            }
			.form{
				margin-top:15%;
			}
			h{
				font-family:vazir;
				color:#000000;
			}
			p{
				text-align:center;
				font-family:vazir;
				font-size:10px;
				color:#000000;
			}
			.forget{
				margin-top:10%;
			}
			.title{
				color:#ffffff;
				margin-top:10%;
				font-size:24px;
				font-weight:normal;
			}
            .list{
				text-align:center;
				font-family:vazir;
				font-size:15px;
				color:#000000;
			}
			a{
				font-family:vazir;
				text-decoration:none;
				color:#000000;
			}
			a:visited{
				color:#000000;
			}

			input{
				background:none;
				text-align:center;
				font-family:vazir;
				border: 2px solid #000000;
				border-radius:50px;
				margin-top:4%;
				margin-left:6%;
				width:50%;
				height:20%;
				color:#000000;
			}
			::placeholder{
				color:#000000;
			}
			button{
				background-color:#000000;
				text-align:center;
				font-family:vazir;
				border: 2px solid #000000;
				border-radius:50px;
				margin-top:4%;
				width:62%;
				color:#000000;
			}
			.lbtn,.lbtn:visited{
				color:#ffffff;
			}
			.hbtn{
				width:48%;
			}
			@font-face{
				font-family:vazir;
				src:url(data/Vazir.ttf);
			}
		</style>
		<?php if(empty($_REQUEST['i'])){$i='';}else{$i=$_REQUEST['i'];} ?>
	</head>
	<body>
		<div class="bg">
        <?php switch($i){
            case 'login':
                echo '<div class="gls">
					<div>
						
						<div class="reg" style="display:none;">
							<svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:3%;vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 21.501 20.186">
							<g xmlns="http://www.w3.org/2000/svg" id="_67" data-name="67" transform="translate(0.75 0.75)">
							<path id="Vector" d="M0,7V4.5A4.494,4.494,0,0,1,4.5,0H7" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-2" data-name="Vector" d="M0,0H2.5A4.494,4.494,0,0,1,7,4.5V7" transform="translate(13)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-3" data-name="Vector" d="M6,0V1.5A4.494,4.494,0,0,1,1.5,6H0" transform="translate(14 14)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-4" data-name="Vector" d="M7,7H4.5A4.494,4.494,0,0,1,0,2.5V0" transform="translate(0 13)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-5" data-name="Vector" d="M14,0H0" transform="translate(3 10)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							</g>
							</svg>
							<button class="hbtn" style="display:none;"><a class="lbtn">ثبت نام</a></button>
							<button class="hbtn" style="display:none;"><a class="lbtn">ورود</a></button>
						</div>
					</div>
				</div>
				<div class="wgls">
					<p class="title">کتابخانه دانشگاه فرهنگیان <svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:3%;vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 21.501 20.186">
						<g id="_65" data-name="65" transform="translate(-1.25 -1.91)">
						<path id="Vector" d="M20,14.078V2.008A1.97,1.97,0,0,0,17.83.018h-.06a18.851,18.851,0,0,0-7.07,2.37l-.17.11a1.108,1.108,0,0,1-1.06,0l-.25-.15A18.757,18.757,0,0,0,2.16.008,1.967,1.967,0,0,0,0,2V14.08a2.055,2.055,0,0,0,1.74,1.98l.29.04a25.693,25.693,0,0,1,7.44,2.44l.04.02a1.08,1.08,0,0,0,.96,0,25.461,25.461,0,0,1,7.46-2.46l.33-.04A2.055,2.055,0,0,0,20,14.078Z" transform="translate(2 2.662)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-2" data-name="Vector" d="M0,0V15" transform="translate(12 5.49)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-3" data-name="Vector" d="M2.25,0H0" transform="translate(5.5 8.49)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-4" data-name="Vector" d="M3,0H0" transform="translate(5.5 11.49)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						</g>
						</svg>
					</p>
					<p class="desc">طراحی پردیس شهید مدرس سنندج</p>
					<div class="form">
						<input placeholder="شناسه ملی"><svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:4%;margin-right:6%;vertical-align:-7px;" width="21.501" height="20.186" viewBox="0 0 24.501 23.186">
						<g xmlns="http://www.w3.org/2000/svg" id="_61" data-name="61" transform="translate(-748 -188)">
						<g id="user-square">
						<path id="Vector" d="M12.28,4.65a11.152,11.152,0,0,1-3.14.38h-6A11.152,11.152,0,0,1,0,4.65C.22,2.05,2.89,0,6.14,0S12.06,2.05,12.28,4.65Z" transform="translate(753.86 204.97)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-2" data-name="Vector" d="M13,0H7C2,0,0,2,0,7v6c0,3.78,1.14,5.85,3.86,6.62.22-2.6,2.89-4.65,6.14-4.65s5.92,2.05,6.14,4.65C18.86,18.85,20,16.78,20,13V7C20,2,18,0,13,0ZM10,12.17a3.585,3.585,0,1,1,3.58-3.59A3.585,3.585,0,0,1,10,12.17Z" transform="translate(750 190)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-3" data-name="Vector" d="M7.16,3.58A3.58,3.58,0,1,1,3.58,0,3.58,3.58,0,0,1,7.16,3.58Z" transform="translate(756.42 195)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 188)" fill="none" opacity="0"/>
						</g>
						</g>
						</svg>
						<br>
						<input placeholder="رمز عبور"><svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:4%;margin-right:6%;vertical-align:-9px;" width="21.501" height="20.186" viewBox="0 0 24.501 23.186">
						<g xmlns="http://www.w3.org/2000/svg" id="_40" data-name="40" transform="translate(-1.252 -1.243)">
						<path id="Vector" d="M17.793,12.923a7.575,7.575,0,0,1-7.6,1.87l-4.71,4.7a1.935,1.935,0,0,1-1.49.49l-2.18-.3a1.888,1.888,0,0,1-1.5-1.5L.013,16A2.015,2.015,0,0,1,.5,14.51l4.7-4.7a7.571,7.571,0,1,1,12.59,3.11Z" transform="translate(1.997 2.007)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-2" data-name="Vector" d="M0,0,2.3,2.3" transform="translate(6.89 17.49)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						<path id="Vector-3" data-name="Vector" d="M3,1.5A1.5,1.5,0,1,1,1.5,0,1.5,1.5,0,0,1,3,1.5Z" transform="translate(13 8)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
						</g>
						</svg>
						</svg>
						<br>
						<button><a class="lbtn">ورود</a></button>
						<br>
						<a>
						<p class="forget">بازیابی رمز عبور <svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:2%;margin-right:6%;vertical-align:-5px;" width="15.501" height="14.186" viewBox="0 0 24.501 23.186">
							<g xmlns="http://www.w3.org/2000/svg" id="_40" data-name="40" transform="translate(-1.252 -1.243)">
							<path id="Vector" d="M17.793,12.923a7.575,7.575,0,0,1-7.6,1.87l-4.71,4.7a1.935,1.935,0,0,1-1.49.49l-2.18-.3a1.888,1.888,0,0,1-1.5-1.5L.013,16A2.015,2.015,0,0,1,.5,14.51l4.7-4.7a7.571,7.571,0,1,1,12.59,3.11Z" transform="translate(1.997 2.007)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-2" data-name="Vector" d="M0,0,2.3,2.3" transform="translate(6.89 17.49)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							<path id="Vector-3" data-name="Vector" d="M3,1.5A1.5,1.5,0,1,1,1.5,0,1.5,1.5,0,0,1,3,1.5Z" transform="translate(13 8)" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
							</g>
							</svg>
						</p>
						</a>
					</div>
				</div>';
            break;
            case 'event':
                echo '<img class="banner" src="https://kurdestan.cfu.ac.ir/view9335/img/custom/banner/1402.png">
                
                <div class="gls">
					<div class="news">
							<p class="event" style="color:#ffffff;text-align:right;">
                            <a class="event" href="https://lib.cfu.ac.ir/portal/tabid/74/ID/11/Default.aspx">  پیام رییس دانشگاه فرهنگیان کشور به مناسبت هفته کتابخوانی <svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:2%;vertical-align:-5px;" width="21.501" height="20.186" viewBox="0 0 24.501 23.186">
								<g xmlns="http://www.w3.org/2000/svg" id="_41" data-name="41" transform="translate(-748 -314)">
								<g id="message-text">
								<path id="Vector" d="M14,0H6Q0,0,0,6V19a1,1,0,0,0,1,1H14q6,0,6-6V6Q20,0,14,0Z" transform="translate(750 316)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<g id="Group">
								<path id="Vector-2" data-name="Vector" d="M0,0H10" transform="translate(755 323.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<path id="Vector-3" data-name="Vector" d="M0,0H7" transform="translate(755 328.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								</g>
								<path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 314)" fill="none" opacity="0"/>
								</g>
								</g>
								</svg></a>
                                </p>
                                <p class="event" style="color:#ffffff;text-align:right;">
                                <a class="event" href="https://lib.cfu.ac.ir/portal/tabid/74/ID/11/Default.aspx">  
  برنامه های بیست و هشتمین دوره هفتة کتاب جمهوری اسلامی ایران در دانشگاه  فرهنگیان </a><svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:2%;vertical-align:-5px;" width="21.501" height="20.186" viewBox="0 0 24.501 23.186">
							    <g xmlns="http://www.w3.org/2000/svg" id="_41" data-name="41" transform="translate(-748 -314)">
								<g id="message-text">
								<path id="Vector" d="M14,0H6Q0,0,0,6V19a1,1,0,0,0,1,1H14q6,0,6-6V6Q20,0,14,0Z" transform="translate(750 316)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<g id="Group">
								<path id="Vector-2" data-name="Vector" d="M0,0H10" transform="translate(755 323.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<path id="Vector-3" data-name="Vector" d="M0,0H7" transform="translate(755 328.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								</g>
								<path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 314)" fill="none" opacity="0"/>
								</g>
								</g>
								</svg>
							</p>
                            
						</div>
				</div>
				<div class="wgls">
					<p style="margin-top:35%;">
                    <a href="http://'. $_SERVER['SERVER_NAME'] .'" title="صفحه اصلی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g xmlns="http://www.w3.org/2000/svg" id="_38" data-name="38" transform="translate(0.75 0.842)">
    <path id="Vector" d="M7.02.823l-5.39,4.2A4.759,4.759,0,0,0,0,8.343v7.41a4.225,4.225,0,0,0,4.21,4.22H15.79A4.223,4.223,0,0,0,20,15.763V8.483a4.723,4.723,0,0,0-1.8-3.45L12.02.7a4.487,4.487,0,0,0-5,.123Z" fill="none" stroke="#292d32" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
  </g>
</svg></a>
<br>
                    <a href="" title="جستجوی کتاب"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_68" data-name="68" transform="translate(-684 -188)">
    <g id="global-search">
      <g id="Group">
        <path id="Vector" d="M20,10A10,10,0,1,0,10,20" transform="translate(686 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M.463,0h1a28.424,28.424,0,0,0,0,18h-1" transform="translate(691.537 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-3" data-name="Vector" d="M0,0A28.555,28.555,0,0,1,1.46,9" transform="translate(699 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-4" data-name="Vector" d="M0,1V0A28.555,28.555,0,0,0,9,1.46" transform="translate(687 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-5" data-name="Vector" d="M0,1.463a28.424,28.424,0,0,1,18,0" transform="translate(687 195.537)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <path id="Vector-6" data-name="Vector" d="M6.4,3.2A3.2,3.2,0,1,1,3.2,0,3.2,3.2,0,0,1,6.4,3.2Z" transform="translate(699 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-7" data-name="Vector" d="M1,1,0,0" transform="translate(705 209)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-8" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(708 212) rotate(180)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="صفحه شخصی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186">
  <g id="_61" data-name="61" transform="translate(-748 -188)">
    <g id="user-square">
      <path id="Vector" d="M12.28,4.65a11.152,11.152,0,0,1-3.14.38h-6A11.152,11.152,0,0,1,0,4.65C.22,2.05,2.89,0,6.14,0S12.06,2.05,12.28,4.65Z" transform="translate(753.86 204.97)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M13,0H7C2,0,0,2,0,7v6c0,3.78,1.14,5.85,3.86,6.62.22-2.6,2.89-4.65,6.14-4.65s5.92,2.05,6.14,4.65C18.86,18.85,20,16.78,20,13V7C20,2,18,0,13,0ZM10,12.17a3.585,3.585,0,1,1,3.58-3.59A3.585,3.585,0,0,1,10,12.17Z" transform="translate(750 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M7.16,3.58A3.58,3.58,0,1,1,3.58,0,3.58,3.58,0,0,1,7.16,3.58Z" transform="translate(756.42 195)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
					<a href="" title="اخبار و رویداد ها"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_9" data-name="9" transform="translate(-172 -252)">
    <g id="calendar-2">
      <path class="menuslct" id="Vector" d="M0,0V3" transform="translate(180 254)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path class="menuslct" id="Vector-2" data-name="Vector" d="M0,0V3" transform="translate(188 254)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path class="menuslct" id="Vector-3" data-name="Vector" d="M0,0H17" transform="translate(175.5 261.09)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path class="menuslct" id="Vector-4" data-name="Vector" d="M18,5v8.5c0,3-1.5,5-5,5H5c-3.5,0-5-2-5-5V5C0,2,1.5,0,5,0h8C16.5,0,18,2,18,5Z" transform="translate(175 255.5)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-5" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(172 252)" fill="none" opacity="0"/>
      <path class="menuslct" id="Vector-6" data-name="Vector" d="M.5.5h0" transform="translate(183.501 265.2)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path class="menuslct" id="Vector-7" data-name="Vector" d="M.5.5h0" transform="translate(179.8 265.2)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path class="menuslct" id="Vector-8" data-name="Vector" d="M.5.5h0" transform="translate(179.8 268.2)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="خدمات کتابخانه"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g id="_15" data-name="15" transform="translate(-236 -188)">
    <g id="convert-3d-cube">
      <g id="Group">
        <path id="Vector" d="M7,0A7,7,0,0,1,0,7L1.05,5.25" transform="translate(251 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M0,7A7,7,0,0,1,7,0L5.95,1.75" transform="translate(238 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <g id="Group-3" data-name="Group">
          <path id="Vector-3" data-name="Vector" d="M0,0,3.98,2.3,7.92.01" transform="translate(249.7 192.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-4" data-name="Vector" d="M0,4.08V0" transform="translate(253.68 194.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-5" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(249.35 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-4" data-name="Group">
        <g id="Group-5" data-name="Group">
          <path id="Vector-6" data-name="Vector" d="M0,0,3.97,2.3,7.92.01" transform="translate(238.35 203.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-7" data-name="Vector" d="M0,4.08V0" transform="translate(242.32 205.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-8" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(238 201)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-9" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(236 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="ارتباط با ما"><svg  class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_34" data-name="34" transform="translate(-428 -250)">
    <g id="messages-2">
      <path id="Vector" d="M14.13,14.83l.39,3.16a1,1,0,0,1-1.5.98L8.83,16.48a9.982,9.982,0,0,1-1.35-.09,4.861,4.861,0,0,0,1.18-3.16,5.327,5.327,0,0,0-5.5-5.14A5.683,5.683,0,0,0,.04,9,6.339,6.339,0,0,1,0,8.24C0,3.69,3.95,0,8.83,0s8.83,3.69,8.83,8.24a8.054,8.054,0,0,1-3.53,6.59Z" transform="translate(432.34 252)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M11,5.14A4.861,4.861,0,0,1,9.82,8.3,5.584,5.584,0,0,1,5.5,10.27L2.89,11.82a.625.625,0,0,1-.94-.61L2.2,9.24A4.988,4.988,0,0,1,0,5.14,5.023,5.023,0,0,1,2.38.91,5.683,5.683,0,0,1,5.5,0,5.327,5.327,0,0,1,11,5.14Z" transform="translate(430 260.09)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(428 250)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
					</div>
				</div>';
            break;
            case 'service':
                echo '<img class="banner" src="https://kurdestan.cfu.ac.ir/view9335/img/custom/banner/1402.png">
                
                <div class="gls">
					<div class="news">
							<p class="event" style="color:#ffffff;text-align:right;"><a class="event" href="https://lib.cfu.ac.ir/portal/tabid/74/ID/11/Default.aspx">  پیام رییس دانشگاه فرهنگیان کشور به مناسبت هفته کتابخوانی <svg xmlns="http://www.w3.org/2000/svg"  style="margin-left:2%;margin-right:6%;vertical-align:-5px;" width="21.501" height="20.186" viewBox="0 0 24.501 23.186">
								<g xmlns="http://www.w3.org/2000/svg" id="_41" data-name="41" transform="translate(-748 -314)">
								<g id="message-text">
								<path id="Vector" d="M14,0H6Q0,0,0,6V19a1,1,0,0,0,1,1H14q6,0,6-6V6Q20,0,14,0Z" transform="translate(750 316)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<g id="Group">
								<path id="Vector-2" data-name="Vector" d="M0,0H10" transform="translate(755 323.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								<path id="Vector-3" data-name="Vector" d="M0,0H7" transform="translate(755 328.5)" fill="#fff" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
								</g>
								<path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 314)" fill="none" opacity="0"/>
								</g>
								</g>
								</svg></a>
							</p>
						</div>
				</div>
				<div class="wgls">
					<p style="margin-top:35%;">
                    <a href="http://'. $_SERVER['SERVER_NAME'] .'" title="صفحه اصلی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g xmlns="http://www.w3.org/2000/svg" id="_38" data-name="38" transform="translate(0.75 0.842)">
    <path id="Vector" d="M7.02.823l-5.39,4.2A4.759,4.759,0,0,0,0,8.343v7.41a4.225,4.225,0,0,0,4.21,4.22H15.79A4.223,4.223,0,0,0,20,15.763V8.483a4.723,4.723,0,0,0-1.8-3.45L12.02.7a4.487,4.487,0,0,0-5,.123Z" fill="none" stroke="#292d32" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
  </g>
</svg></a>
<br>
                    <a href="" title="جستجوی کتاب"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_68" data-name="68" transform="translate(-684 -188)">
    <g id="global-search">
      <g id="Group">
        <path id="Vector" d="M20,10A10,10,0,1,0,10,20" transform="translate(686 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M.463,0h1a28.424,28.424,0,0,0,0,18h-1" transform="translate(691.537 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-3" data-name="Vector" d="M0,0A28.555,28.555,0,0,1,1.46,9" transform="translate(699 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-4" data-name="Vector" d="M0,1V0A28.555,28.555,0,0,0,9,1.46" transform="translate(687 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-5" data-name="Vector" d="M0,1.463a28.424,28.424,0,0,1,18,0" transform="translate(687 195.537)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <path id="Vector-6" data-name="Vector" d="M6.4,3.2A3.2,3.2,0,1,1,3.2,0,3.2,3.2,0,0,1,6.4,3.2Z" transform="translate(699 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-7" data-name="Vector" d="M1,1,0,0" transform="translate(705 209)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-8" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(708 212) rotate(180)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="صفحه شخصی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186">
  <g id="_61" data-name="61" transform="translate(-748 -188)">
    <g id="user-square">
      <path id="Vector" d="M12.28,4.65a11.152,11.152,0,0,1-3.14.38h-6A11.152,11.152,0,0,1,0,4.65C.22,2.05,2.89,0,6.14,0S12.06,2.05,12.28,4.65Z" transform="translate(753.86 204.97)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M13,0H7C2,0,0,2,0,7v6c0,3.78,1.14,5.85,3.86,6.62.22-2.6,2.89-4.65,6.14-4.65s5.92,2.05,6.14,4.65C18.86,18.85,20,16.78,20,13V7C20,2,18,0,13,0ZM10,12.17a3.585,3.585,0,1,1,3.58-3.59A3.585,3.585,0,0,1,10,12.17Z" transform="translate(750 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M7.16,3.58A3.58,3.58,0,1,1,3.58,0,3.58,3.58,0,0,1,7.16,3.58Z" transform="translate(756.42 195)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
					<a href="" title="اخبار و رویداد ها"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_9" data-name="9" transform="translate(-172 -252)">
    <g id="calendar-2">
      <path id="Vector" d="M0,0V3" transform="translate(180 254)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M0,0V3" transform="translate(188 254)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M0,0H17" transform="translate(175.5 261.09)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-4" data-name="Vector" d="M18,5v8.5c0,3-1.5,5-5,5H5c-3.5,0-5-2-5-5V5C0,2,1.5,0,5,0h8C16.5,0,18,2,18,5Z" transform="translate(175 255.5)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-5" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(172 252)" fill="none" opacity="0"/>
      <path id="Vector-6" data-name="Vector" d="M.5.5h0" transform="translate(183.501 265.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path id="Vector-7" data-name="Vector" d="M.5.5h0" transform="translate(179.8 265.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path id="Vector-8" data-name="Vector" d="M.5.5h0" transform="translate(179.8 268.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="خدمات کتابخانه"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g id="_15" data-name="15" transform="translate(-236 -188)">
    <g id="convert-3d-cube">
      <g id="Group">
        <path id="Vector" d="M7,0A7,7,0,0,1,0,7L1.05,5.25" transform="translate(251 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M0,7A7,7,0,0,1,7,0L5.95,1.75" transform="translate(238 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <g id="Group-3" data-name="Group">
          <path id="Vector-3" data-name="Vector" d="M0,0,3.98,2.3,7.92.01" transform="translate(249.7 192.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-4" data-name="Vector" d="M0,4.08V0" transform="translate(253.68 194.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-5" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(249.35 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-4" data-name="Group">
        <g id="Group-5" data-name="Group">
          <path id="Vector-6" data-name="Vector" d="M0,0,3.97,2.3,7.92.01" transform="translate(238.35 203.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-7" data-name="Vector" d="M0,4.08V0" transform="translate(242.32 205.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-8" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(238 201)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-9" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(236 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="ارتباط با ما"><svg  class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_34" data-name="34" transform="translate(-428 -250)">
    <g id="messages-2">
      <path id="Vector" d="M14.13,14.83l.39,3.16a1,1,0,0,1-1.5.98L8.83,16.48a9.982,9.982,0,0,1-1.35-.09,4.861,4.861,0,0,0,1.18-3.16,5.327,5.327,0,0,0-5.5-5.14A5.683,5.683,0,0,0,.04,9,6.339,6.339,0,0,1,0,8.24C0,3.69,3.95,0,8.83,0s8.83,3.69,8.83,8.24a8.054,8.054,0,0,1-3.53,6.59Z" transform="translate(432.34 252)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M11,5.14A4.861,4.861,0,0,1,9.82,8.3,5.584,5.584,0,0,1,5.5,10.27L2.89,11.82a.625.625,0,0,1-.94-.61L2.2,9.24A4.988,4.988,0,0,1,0,5.14,5.023,5.023,0,0,1,2.38.91,5.683,5.683,0,0,1,5.5,0,5.327,5.327,0,0,1,11,5.14Z" transform="translate(430 260.09)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(428 250)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
					</div>
				</div>';
            break;
            default:
                echo '<img class="banner" src="https://kurdestan.cfu.ac.ir/view9335/img/custom/banner/1402.png">
                
                <div class="gls" style="background-size:auto 100%;background-position:center center;">
					<div>
                        <p class="slidebtm"> <a class="slctd" id="slide0" onclick="slide(0)">•</a> <a class="dot" id="slide1" onclick="slide(1)">•</a> <a class="dot" id="slide2" onclick="slide(2)">•</a> <a class="dot" id="slide3" onclick="slide(3)">•</a> </p>
					</div>
				</div>
                <script>
                var slides = ["https://kurdestan.cfu.ac.ir/cache/198/attach/202304/745343_3632888118_1210_400.jpg","https://kurdestan.cfu.ac.ir/cache/198/attach/202305/749027_1745661500_1210_400.jpg","https://kurdestan.cfu.ac.ir/cache/198/attach/202305/750857_2249758586_1210_400.jpg"];
                function slide(x){
                    document.getElementsByClassName("slctd")[0].class="dot";
                    document.getElementById(x).class="slctd";
                    var img = slides.x;
                }
                if(!img){
                    var img = "https://kurdestan.cfu.ac.ir/cache/198/attach/202304/745343_3632888118_1210_400.jpg"
                }
                document.getElementsByClassName("gls")[0].style.backgroundImage="url("+ img +")";
                </script>
				<div class="wgls">
					<p style="margin-top:35%;">
                    <a title="صفحه اصلی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g xmlns="http://www.w3.org/2000/svg" id="_38" data-name="38" transform="translate(0.75 0.842)">
    <path id="Vector" d="M7.02.823l-5.39,4.2A4.759,4.759,0,0,0,0,8.343v7.41a4.225,4.225,0,0,0,4.21,4.22H15.79A4.223,4.223,0,0,0,20,15.763V8.483a4.723,4.723,0,0,0-1.8-3.45L12.02.7a4.487,4.487,0,0,0-5,.123Z" fill="none" class="menuslct" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
  </g>
</svg></a>
<br>
                    <a href="" title="جستجوی کتاب"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_68" data-name="68" transform="translate(-684 -188)">
    <g id="global-search">
      <g id="Group">
        <path id="Vector" d="M20,10A10,10,0,1,0,10,20" transform="translate(686 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M.463,0h1a28.424,28.424,0,0,0,0,18h-1" transform="translate(691.537 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-3" data-name="Vector" d="M0,0A28.555,28.555,0,0,1,1.46,9" transform="translate(699 191)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-4" data-name="Vector" d="M0,1V0A28.555,28.555,0,0,0,9,1.46" transform="translate(687 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-5" data-name="Vector" d="M0,1.463a28.424,28.424,0,0,1,18,0" transform="translate(687 195.537)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <path id="Vector-6" data-name="Vector" d="M6.4,3.2A3.2,3.2,0,1,1,3.2,0,3.2,3.2,0,0,1,6.4,3.2Z" transform="translate(699 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-7" data-name="Vector" d="M1,1,0,0" transform="translate(705 209)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-8" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(708 212) rotate(180)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="صفحه شخصی"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186">
  <g id="_61" data-name="61" transform="translate(-748 -188)">
    <g id="user-square">
      <path id="Vector" d="M12.28,4.65a11.152,11.152,0,0,1-3.14.38h-6A11.152,11.152,0,0,1,0,4.65C.22,2.05,2.89,0,6.14,0S12.06,2.05,12.28,4.65Z" transform="translate(753.86 204.97)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M13,0H7C2,0,0,2,0,7v6c0,3.78,1.14,5.85,3.86,6.62.22-2.6,2.89-4.65,6.14-4.65s5.92,2.05,6.14,4.65C18.86,18.85,20,16.78,20,13V7C20,2,18,0,13,0ZM10,12.17a3.585,3.585,0,1,1,3.58-3.59A3.585,3.585,0,0,1,10,12.17Z" transform="translate(750 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M7.16,3.58A3.58,3.58,0,1,1,3.58,0,3.58,3.58,0,0,1,7.16,3.58Z" transform="translate(756.42 195)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-4" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(748 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
					<a href="http://'. $_SERVER['SERVER_NAME'] .'?i=event" title="اخبار و رویداد ها"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_9" data-name="9" transform="translate(-172 -252)">
    <g id="calendar-2">
      <path id="Vector" d="M0,0V3" transform="translate(180 254)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M0,0V3" transform="translate(188 254)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M0,0H17" transform="translate(175.5 261.09)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-4" data-name="Vector" d="M18,5v8.5c0,3-1.5,5-5,5H5c-3.5,0-5-2-5-5V5C0,2,1.5,0,5,0h8C16.5,0,18,2,18,5Z" transform="translate(175 255.5)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-5" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(172 252)" fill="none" opacity="0"/>
      <path id="Vector-6" data-name="Vector" d="M.5.5h0" transform="translate(183.501 265.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path id="Vector-7" data-name="Vector" d="M.5.5h0" transform="translate(179.8 265.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
      <path id="Vector-8" data-name="Vector" d="M.5.5h0" transform="translate(179.8 268.2)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="خدمات کتابخانه"><svg class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"><g id="_15" data-name="15" transform="translate(-236 -188)">
    <g id="convert-3d-cube">
      <g id="Group">
        <path id="Vector" d="M7,0A7,7,0,0,1,0,7L1.05,5.25" transform="translate(251 203)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        <path id="Vector-2" data-name="Vector" d="M0,7A7,7,0,0,1,7,0L5.95,1.75" transform="translate(238 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-2" data-name="Group">
        <g id="Group-3" data-name="Group">
          <path id="Vector-3" data-name="Vector" d="M0,0,3.98,2.3,7.92.01" transform="translate(249.7 192.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-4" data-name="Vector" d="M0,4.08V0" transform="translate(253.68 194.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-5" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(249.35 190)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <g id="Group-4" data-name="Group">
        <g id="Group-5" data-name="Group">
          <path id="Vector-6" data-name="Vector" d="M0,0,3.97,2.3,7.92.01" transform="translate(238.35 203.45)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
          <path id="Vector-7" data-name="Vector" d="M0,4.08V0" transform="translate(242.32 205.74)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
        </g>
        <path id="Vector-8" data-name="Vector" d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21a2.186,2.186,0,0,0-1.87,0Z" transform="translate(238 201)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      </g>
      <path id="Vector-9" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(236 188)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
<br>
                    <a href="" title="ارتباط با ما"><svg  class="menu" xmlns="http://www.w3.org/2000/svg"  style="vertical-align:-5px;" width="26.501" height="25.186" viewBox="0 0 24.501 23.186"> <g id="_34" data-name="34" transform="translate(-428 -250)">
    <g id="messages-2">
      <path id="Vector" d="M14.13,14.83l.39,3.16a1,1,0,0,1-1.5.98L8.83,16.48a9.982,9.982,0,0,1-1.35-.09,4.861,4.861,0,0,0,1.18-3.16,5.327,5.327,0,0,0-5.5-5.14A5.683,5.683,0,0,0,.04,9,6.339,6.339,0,0,1,0,8.24C0,3.69,3.95,0,8.83,0s8.83,3.69,8.83,8.24a8.054,8.054,0,0,1-3.53,6.59Z" transform="translate(432.34 252)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-2" data-name="Vector" d="M11,5.14A4.861,4.861,0,0,1,9.82,8.3,5.584,5.584,0,0,1,5.5,10.27L2.89,11.82a.625.625,0,0,1-.94-.61L2.2,9.24A4.988,4.988,0,0,1,0,5.14,5.023,5.023,0,0,1,2.38.91,5.683,5.683,0,0,1,5.5,0,5.327,5.327,0,0,1,11,5.14Z" transform="translate(430 260.09)" fill="none" class="menubtn" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="Vector-3" data-name="Vector" d="M0,0H24V24H0Z" transform="translate(428 250)" fill="none" opacity="0"/>
    </g>
  </g>
</svg></a>
					</div>
				</div>';
        } ?>
		</div>
	</body>
</html>